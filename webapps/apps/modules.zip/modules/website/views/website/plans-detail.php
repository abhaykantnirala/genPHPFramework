<!-------------banner---------->
<section class="banner banner-inner">
    <img src="<?php echo $this->helper->url->baseurl('public/assets/images/banner-img1.jpg');?>" alt="" />
    <h2>Plans Detail</h2>
</section>


<!-----------Pricing plan sec-------->
<section class="sec">
    <div class="container">
        <h2>Our Plans Detail</h2>
        <div class="row">
            <div class="col-md-12 my-plans-detail">
                <div class="plan-full-img">
                    <img src="<?php echo $this->helper->url->baseurl('public/assets/images/slider-img1.jpg');?>" alt="" />
                </div>
                <div class="plan-detail">
                    <h3>Welcome To Our shaving Company</h3>
                    <p>Lorem ipsum is simply free text dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation tempor. Lorem ipsum is simply free text dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation tempor.</p>
                    <ul class="check-list">
                        <li><i class="fa fa-check-circle"></i> Suspe ndisse suscipit sagittis leo.</li>
                        <li><i class="fa fa-check-circle"></i> Entum estibulum dignissim posuere.</li>
                        <li><i class="fa fa-check-circle"></i> Lorem Ipsum gene on the tend to repeat.</li>
                    </ul>
                    <p>Lorem ipsum is simply free text dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation tempor. Lorem ipsum is simply free text dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation tempor.</p>
                </div>
            </div>

        </div>
    </div>
</section>