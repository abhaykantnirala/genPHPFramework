<!-------------banner---------->
<section class="banner banner-inner">
    <img src="<?php echo $this->helper->url->baseurl('public/assets/images/banner-img1.jpg'); ?>" alt="" />
    <h2>About us</h2>
</section>

<!-----------about sec-------->
<section class="sec">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="about-img">
                    <img class="about-img-sm" src="<?php echo $this->helper->url->baseurl('public/assets/images/about-floating-img1.jpg'); ?>" alt="" />
                    <img src="<?php echo $this->helper->url->baseurl('public/assets/images/about1.jpg'); ?>" class="about-img-lg" alt="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="about-content">
                    <h2>Welcome To Our shaving Company</h2>
                    <p>Lorem ipsum is simply free text dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation tempor.</p>
                    <ul class="check-list">
                        <li><i class="fa fa-check-circle"></i> Suspe ndisse suscipit sagittis leo.</li>
                        <li><i class="fa fa-check-circle"></i> Entum estibulum dignissim posuere.</li>
                        <li><i class="fa fa-check-circle"></i> Lorem Ipsum gene on the tend to repeat.</li>
                    </ul>
                    <a href="#" class="btn custom-btn">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section> 