<!-------------banner---------->
<section class="banner banner-inner">
	<img src="<?php echo $this->helper->url->baseurl('public/assets/images/banner-img1.jpg');?>" alt="" />
    <h2>Terms & Condition</h2>
</section>

<!-----------about sec-------->
<section class="sec">
	<div class="container">
    	Text, photographs, graphics and sound contained on the site are owned by JMD Marketing.

All information, illustrations, photographs, images, text, video clips (with or without sound), and other content appearing on the existing site are subject to industrial and/or intellectual property rights; they are the property of either JMD Marketing or the third-party authorizing their limited use by JMD Marketing or one of its subsidiaries. Accordingly, any reproduction, broadcast, adaptation, translation and/or modification, partial or complete, or distribution to another website is prohibited. Partial or complete reproduction of this proprietary content without JMD Marketing prior written consent is strictly prohibited, with the exception of press photographs included in the photo library of the News section.

All JMD Marketing brands listed on this site are registered brand names.
    </div>
</section> 