<div>
    <h1>Following user want to connect !!!</h1>
    <table>
        <tr>
            <td>First Name </td>
            <td>: <?php echo ucfirst(strtolower($first_name)); ?></td>
        </tr>
        <tr>
            <td>Last Name </td>
            <td>: <?php echo ucfirst(strtolower($last_name)); ?></td>
        </tr>
        <tr>
            <td>Email </td>
            <td>: <?php echo $email; ?></td>
        </tr>
        <tr>
            <td>Phone </td>
            <td>: <?php echo $phone; ?></td>
        </tr>
        <tr>
            <td>Message </td>
            <td>: <?php echo $message; ?></td>
        </tr>
    </table>
</div>