<?php

/**
 * @users controller
 * */
class users extends gcontroller {

    private $data = array();

    function __construct() {
        parent::__construct();
        $this->data['_title'] = 'Software / Web / App Development Company | Saas Websol';
        $this->data['_meta_decp'] = 'Saas Websol - Software / Web / App Development Company | Saas Websol';
        $this->load->model('users');
    }

    public function index() {
        $this->data['udata'] = $this->session->getdata('user-session-data');
        $this->data['user_emi_data'] = $this->model->users->get_user_emi($this->data['udata']->id);
        $this->data['policy_details'] = $this->load->view('users/get-user-emi', $this->data, true);
        
        $this->load->layout->website('index', $this->data);
    }
    
    public function logout(){
        #clear session
        $this->session->setdata('user-session-data', '');
        #redirect to login page
        $this->helper->url->redirect('home');
    }
    
    public function login(){
        #get users post data
        $data = $this->helper->input->post();
        $udata = $this->model->users->user_login($data);
        if (isset($udata->id)){
            $res = array(
                'status' => 'success',
                'code' => 200,
                'msg' => 'Login successfully'
            );
            #set session data here
            $this->session->setdata('user-session-data', $udata);
        } else {
            $res = array(
                'status' => 'fail',
                'code' => 401,
                'msg' => 'Invalid credentials'
            );
        }
        echo json_encode($res);
    }
}