<?php

namespace model;

use gmodel;

class admin extends gmodel {

    function __construct() {
        parent::__construct();
    }

    public function check_login($email, $pwd) {
        $where = array(
            array('email', '=', $email),
            'and',
            array('password', '=', md5($pwd)),
        );
        return $this->db->table('admins')->select()->where($where)->execute()->row();
    }

}
